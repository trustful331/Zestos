import Home from "@/container/Home";
export default function HomePage() {
  return (
    <>
      <Home />
    </>
  );
}
